<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/my_webpage/db/db_connect.php';

$id = $_POST['id'];
$pass = $_POST['password'];
$name = $_POST['name'];
$email = $_POST['email'];

$sql = "update members set pass='$pass', name='$name' , email='$email'";
$sql .= " where id='$id'";
//select => record set, update, insert, delete => true, false
$value = mysqli_query( $con, $sql ) or die( 'error : ' . mysqli_error( $con ) );
if ( $value ) {
    session_start();
    $_SESSION['username'] = $name;
} else {
    echo "<script>
                    alert('정보 수정 실패');
                    history.go(-1);
              </script>";
}

mysqli_close( $con );

echo "
	      <script>
	          alert('수정 완료');
	          location.href = 'http://{$_SERVER['HTTP_HOST']}/my_webpage/index.php';
	      </script>
	  ";
?>

