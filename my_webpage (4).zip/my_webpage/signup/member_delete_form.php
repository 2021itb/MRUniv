<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>경아 페이지</title>
    <link rel="stylesheet" type="text/css" href="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/css/common.css">
    <link rel="stylesheet" type="text/css" href="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/signup/css/member.css">
    <script src="https://kit.fontawesome.com/5bc9c3ab86.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/banner.css">
    <link rel="stylesheet" href="../css/normalize.css">
    <script src="https://kit.fontawesome.com/5bc9c3ab86.js" crossorigin="anonymous"></script>
    <script src="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/member/js/member.js" defer></script>
    <script src="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/js/common.js" defer></script>
</head>

<body>
    <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/my_webpage/header.php"; ?>
    </header>
    <section>
        <div id="main_content">
            <div id="join_box">
                <h2>정말로 회원탈퇴를 하시겠습니까?</h2>
                <form name="member_form" method="post" action="./member_delete.php">
                    <input type="hidden" name="id" value="<?=$userid?>">
                    <br><br>
                    <div>
                        <input type="submit" value="확인">
                    </div>
                </form>
            </div> <!-- join_box -->
        </div> <!-- main_content -->
    </section>
    <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/my_webpage/footer.php"; ?>
    </footer>
</body>

</html>