<?php
//데이타 베이스 연동  및 members 테이블 생성
include_once $_SERVER['DOCUMENT_ROOT'].'/my_webpage/db/db_connect.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/my_webpage/db/create_table.php';
create_table( $con, 'members' );
create_table( $con, 'delete_members' ); // 회원 탈퇴 테이블

$id = input_set( $_POST['id'] );
$pass = $_POST['password'];
$name = $_POST['name'];
$email = $_POST['email'];

$regist_day = date( 'Y-m-d (H:i)' );
// 현재의 '년-월-일-시-분'을 저장

$sql = 'insert into members(id, pass, name, email, regist_day, level, point) ';
$sql .= "values('$id', '$pass', '$name', '$email', '$regist_day', 9, 10)";

$insert_result = mysqli_query( $con, $sql );
// $sql 에 저장된 명령 실행
mysqli_close( $con );

if ( $insert_result === false ) {
    alert_back( '삽입이 잘못 되었습니다. 다시 입력요청합니다. ' );
} else {
    echo "
        <script>
             alert('회원가입을 축하합니다.');
             location.href = 'http://{$_SERVER['HTTP_HOST']}/my_webpage/index.php';
        </script>
        ";
}
?>