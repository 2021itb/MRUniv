<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name = "viewport" content="width=device-width, initial-scal=1.0">
    <link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/signup/css/member.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/normalize.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/banner.css">
    <script src="https://kit.fontawesome.com/5bc9c3ab86.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@1,200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="../signup/js/member.js" defer></script>

	<title>Document</title>
</head>
<body>
	<header><?php include $_SERVER['DOCUMENT_ROOT'] . "/my_webpage/header.php"; ?></header>
    <h2>회원가입</h2>
    <form name="member_form" method="post" action="./member_insert.php">
    <table>
        <tr>
            <th>아이디</th>
            <td>
                <span class="text1">영문자. 숫자만 입력 가능. 최소 3자이상 입력하세요.</span> <br>
                <input type="text" name="id" id="id" class="essential_form" size="12" value="" onkeyup="idCheck()">  <input type="button" value="아이디 중복확인">
                <span id="idCorrect" class="idCorrect"></span>
            </td>
        </tr>
        <tr>
            <th>비밀번호</th>
            <td>
                <span class="text1">영문자,숫자,특수문자를 포함하여 6~12자를 입력하세요.</span> <br>
                <input type="password" name="password" id="password" class="essential_form" onkeyup = "pwCheck()">
                <span id="pwCorrect"></span> </td>
        </tr>
        <tr>
            <th>비밀번호 확인</th>
            <td><input type="password" name="password_ok" class="essential_form" id="password_ok"  size="20" onkeyup = "pwCheck2()"> 
            <span id="pwCorrect2"></span>          
        </td>
        </tr>
        <tr>
            <th>이름</th>
            <td>
				<input id="name" type="text" name="name"></td>
        </tr>
        <tr>
            <th>E-mail</th>
            <td><input id="email" type="email" name="email" id="Email"> <input type="checkbox" name="chectbox" id="chectbox"> 메일 수신여부
            </td> 
        </tr>
    </table>   
    <tf class="insert">
        <br><input type="button" value="회원가입" onclick="check_input(0)"><br>
    </tf> 
    </form>
  </body>
  <footer><?php include $_SERVER['DOCUMENT_ROOT'] . "/my_webpage/footer.php"; ?>
  
  </footer>
</html>
