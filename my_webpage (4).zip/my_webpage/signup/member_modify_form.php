<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>양원 페이지</title>
    <link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/signup/css/member_modify.css?after=2">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <!-- <script src="../signup/js/member.js" defer></script> -->
    <script src="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/signup/js/member.js" defer></script>
    <script src="http://<?=$_SERVER["HTTP_HOST"]?>/my_webpage/js/common.js" defer></script>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/normalize.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/banner.css">
    <script src="https://kit.fontawesome.com/5bc9c3ab86.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@1,200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/my_webpage/header.php"; ?>
    </header>
    <?php
		    //반복이 되더라도 한버만 포함시킴
            include_once $_SERVER['DOCUMENT_ROOT']."/my_webpage/db/db_connect.php";
            $sql = "select * from members where id='$userid'";
			//쿼리문을 실행 =>실행결과값을 레코드셋 저장
            $result = mysqli_query($con, $sql) or die('error : ' . mysqli_error($con));
			//레코드셋에서 첫번째 레코드를 연관배열저장($row)
            $row = mysqli_fetch_array($result);

            $pass = $row["pass"];
            $name = $row["name"];

			// //rlaeogus0911@nate.com => $email[0]="rlaeogus0911", $email[1]="nate.com"
            // $email = explode("@", $row["email"]);
            // $email1 = $email[0];
            // $email2 = $email[1];

            $email = $row["email"];

            mysqli_close($con);
        ?>
    <section>
        <!-- <?php include $_SERVER['DOCUMENT_ROOT'] . "/my_webpage/main_img_bar.php"; ?> -->
        <div id="main_content">
            <div id="join_box">

                <h2>회원 정보 수정</h2>
                <form name="member_modify_form" method="post" action="./member_modify.php">
                    <table>
                        <tr>
                            <th>사용자 ID</th>
                            <td><?= $userid ?> <input id="id" type="hidden" name="id" value="<?=$userid?>">
                        </tr>
                        <tr>
                            <th>비밀번호</th>
                            <td><input id="password" type="password" name="password" value="<?= $pass ?>">
                                <!--									4~12자리의 영문,숫자,특수문자(!, @, $, %, ^,&,*)만 가능-->
                            </td>
                        </tr>
                        <tr>
                            <th>비밀번호 확인</th>
                            <td colspan="2"><input id="password_ok" type="password" name="password_ok" value="<?= $pass ?>"></td>
                        </tr>
                        <tr>
                            <th>성명</th>
                            <td><input id="name" type="text" name="name" value="<?= $name ?>">
                            </td>
                        </tr>
                        <tr>
                            <th>E-mail</th>
                            <td><input id="email" type="text" name="email" value="<?= $email ?>">

                            </td>
                        </tr>
                    </table>
                    <br>
                    <div id="button1">
                        <input type="button" value="수정" onclick="check_input(1)">
                        <input type="button" value="취소"
                            onclick="location.href='http://<?=$_SERVER['HTTP_HOST']?>/my_webpage/index.php'">
                    </div>
                </form>
            </div> <!-- join_box -->
        </div> <!-- main_content -->
    </section>
    <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/my_webpage/footer.php"; ?>
    </footer>
</body>

</html>