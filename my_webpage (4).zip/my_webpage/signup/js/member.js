function idCheck(){
    var $id = document.getElementById("id");
    var $idCorrect = document.getElementById("idCorrect");
    var idExp = /^[0-9a-zA-z]{3,11}$/;
    if($id.value === ""){
        $idCorrect.innerHTML ="아이디를 입력해주세요.";
        return false;
    }else if($id.value.match(idExp)){
        $idCorrect.innerHTML ="입력확인";
        return false;
    }else{
        $idCorrect.innerHTML ="조건에 맞지 않는 아이디 입니다.";
        return true;
    }
}

function pwCheck(){   
    var $password = document.getElementById("password");
    var $pwCorrect = document.getElementById("pwCorrect");
    var pwExp = /^.*(?=^.{6,12}$)(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&+=]).*$/;
    if($password.value === ""){
        $pwCorrect.innerHTML ="패스워드를 입력해주세요";
        return false;
    }else if($password.value.match(pwExp)){
        $pwCorrect.innerHTML ="입력이 완료되었습니다.";
        return false;
    }else{
        $pwCorrect.innerHTML ="패스워드를 다시확인해주세요";
        return true;
    }
}

function pwCheck2(){
    var $password = document.getElementById("password");
    var $password_ok = document.getElementById("password_ok");
    var $pwCorrect2 = document.getElementById("pwCorrect2");
    if($password.value === $password_ok.value){
        $pwCorrect2.innerHTML ="패스워드가 일지합니다.";
        return true;
    }else{
        $pwCorrect2.innerHTML = "패스워드가 불일치합니다.";
        return false;
    }

}

function check_input(flag) {
    var id = document.getElementById("id");
    var password = document.getElementById("password");
    var password_ok = document.getElementById("password_ok");
    var name = document.getElementById("name");
    var email = document.getElementById("email");
    // getElementById("id");

    if (!id.value) {
        alert("아이디를 입력하세요!");
        document.member_form.id.focus();
        return;
    }

    if (!password.value) {
        alert("비밀번호를 입력하세요!");
        getElementById("password").focus();
        return;
    }

    if (!password_ok.value) {
        alert("비밀번호확인을 입력하세요!");
        getElementById("password_ok").focus();
        return;
    }

    if (!name.value) {
        alert("이름을 입력하세요!");
        getElementById("name").focus();
        return;
    }

    if (!email.value) {
        alert("이메일 주소를 입력하세요!");
        getElementById("email").focus();
        return;
    }

    if (password.value !==
        password_ok.value) {
        alert("비밀번호가 일치하지 않습니다.\n다시 입력해 주세요!");
        getElementById("password").focus();
        getElementById("password").select();
        return;
    }
    
    // 서버에 전송하는기능 member_insert.php
    if(flag == 0){
        document.member_form.submit();
    }else {
        document.member_modify_form.submit();
    }
}

function reset_form() {
    document.member_form.id.value = "";
    document.member_form.pass.value = "";
    document.member_form.pass_confirm.value = "";
    document.member_form.name.value = "";
    document.member_form.email1.value = "";
    document.member_form.email2.value = "";
    document.member_form.id.focus();
    return;
}

function check_id() {
    window.open("member_check_id.php?id=" + document.member_form.id.value,
        "IDcheck",
        "left=700,top=300,width=350,height=200,scrollbars=no,resizable=yes");
}
