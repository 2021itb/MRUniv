<div class = "logo"><i class="fas fa-university">
    </i> 
    <br>Conpyright 2021&copy;
    <br>미래대학교
    <br> Copyright (c) Hdfs Language and Literature . All right reserved.
</div>
<div class="features">
    <h3 class="h3">주소</h3>
    <ul class="features-content">
        <li>01369|서울 도봉구 삼양로144길 33 (쌍문동, 미래대학교)|미래대학교</li>
        <li> (ARS) 02-901-8000 </li>
    </ul>
</div> 
<div class="resources">
    <h3 class="h3">팩스</h3>
    <ul class="features-content">
        <li>상담센터 02-543-4321 </li>
        <li>서비스센터 02-987-6543</li>
    </ul>
</div>
<div class="about">
    <h3 class="h3">전화</h3>
    <ul class="features-content">
        <li>학생상담센터:02-123-1235</li>
        <li>학생서비스센터:02-123-0987</li>
    </ul>
</div>