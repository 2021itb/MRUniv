<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- jquery library londing-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/5bc9c3ab86.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@1,200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <link rel="stylesheet" href="./css/main.css?">
    <link rel="stylesheet" href="./css/footer.css">
    <link rel="stylesheet" href="./css/banner.css">
    <link rel="stylesheet" href="./css/normalize.css">
    <script src="./js/silde.js" defer></script>

    <script src ="./js/common.js" defer></script>
    <title>아동가족학전공</title>
</head>
<body onload="slide_func()">
    <!--$_SERVER['DOCUMENT_ROOT'] => c:\kkk\apm\apache24\htdocs\-->
    <!--c:\bbb\apm\apache24\hdocs-->
    <header>
       <?php include $_SERVER['DOCUMENT_ROOT']."/my_webpage/header.php"; ?>
    </header>
    <section>
       <?php include $_SERVER['DOCUMENT_ROOT']."/my_webpage/main.php"; ?>
    </section>
    <footer>
        <?php include $_SERVER['DOCUMENT_ROOT']."/my_webpage/footer.php"; ?>
    </footer>
</body>
</html>