<?php
	echo "<img src="cat.jpg">";
?>

