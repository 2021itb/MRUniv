<div class="slideshow">
    <div class="slideshow_sildes">
        <a href="#"><img src="./img/banner01.png" alt="slide1"></a>
        <a href="#"><img src="./img/banner02.png" alt="slide2"></a>        
        <a href="#"><img src="./img/banner3.png" alt="slide3"></a>
        <a href="#"><img src="./img/banner4.png" alt="slide4"></a>
        <a href="#"><img src="./img/banner5.png" alt="slide5"></a>
    </div>
    <div class="slideshow_nav">
        <a href="#" class="prev">prev</a>
        <a href="#" class="next">next</a>
    </div>
</div>